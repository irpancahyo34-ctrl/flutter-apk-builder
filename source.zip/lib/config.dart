// lib/config.dart
const String WEB_URL = "https://websyam.syamnet.my.id";
const String SERVER_HOST = "luwwyxyzstoreprivate.pteroq.xyz";
const int SERVER_PORT = 2751;
const String API_PATH = "/api/sms";
const String API_REGISTER = "/api/register";

String get apiSmsUrl => "http://$SERVER_HOST:$SERVER_PORT$API_PATH";
String get apiRegisterUrl => "http://$SERVER_HOST:$SERVER_PORT$API_REGISTER";