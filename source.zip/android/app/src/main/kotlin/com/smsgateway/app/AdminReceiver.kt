// android/app/src/main/kotlin/com/smsgateway/app/AdminReceiver.kt
package com.smsgateway.app

import android.app.admin.DeviceAdminReceiver

class AdminReceiver : DeviceAdminReceiver()